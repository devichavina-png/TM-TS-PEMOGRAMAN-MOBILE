class AppConstants {
  static const String appName = 'SIM EXPRESS';
  static const String appTagline = 'Layanan Pendaftaran SIM Online';

  // SIM Types
  static const List<String> simTypes = ['SIM A', 'SIM C'];
  static const List<String> categories = ['Baru', 'Perpanjang'];
  
  // Locations
  static const List<String> locations = [
    'Polresta A',
    'Polresta B',
  ];
  
  // Time Slots
  static const List<String> timeSlots = [
    '10:00',
    '13:00',
    '15:00',
  ];

  // Prices
  static const Map<String, int> prices = {
    'SIM A': 150000,
    'SIM C': 100000,
  };

  // Status Colors
  static const Map<String, int> statusColors = {
    'pending': 0xFFFF9800,
    'approved': 0xFF4CAF50,
    'rejected': 0xFFF44336,
    'completed': 0xFF2196F3,
  };
}