import '../models/user.dart';
import '../models/sim_application.dart';

class AppStorage {
  static final AppStorage _instance = AppStorage._internal();
  factory AppStorage() => _instance;
  AppStorage._internal();

  List<User> users = [
    User(
      email: 'admin@app.com',
      password: 'admin123',
      name: 'Admin',
      isAdmin: true,
    ),
    User(
      email: 'user@test.com',
      password: 'user123',
      name: 'Budi',
      isAdmin: false,
    ),
  ];

  List<SIMApplication> applications = [];

  String generateId() => DateTime.now().millisecondsSinceEpoch.toString();

  void addApplication(SIMApplication app) => applications.add(app);

  void updateApplication(SIMApplication app) {
    final index = applications.indexWhere((a) => a.id == app.id);
    if (index != -1) applications[index] = app;
  }

  void deleteApplication(String id) {
    applications.removeWhere((app) => app.id == id);
  }

  List<SIMApplication> getUserApplications(String userId) {
    return applications.where((app) => app.userId == userId).toList();
  }

  List<SIMApplication> getPendingApplications() {
    return applications.where((app) => app.status == 'pending').toList();
  }

  List<SIMApplication> getApplicationsByStatus(String status) {
    return applications.where((app) => app.status == status).toList();
  }
}