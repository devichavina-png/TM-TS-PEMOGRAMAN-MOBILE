import 'package:flutter/material.dart';
import 'dart:io';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import '../../models/user.dart';
import '../../models/sim_application.dart';
import '../../utils/app_storage.dart';
import 'payment_page.dart';


class RegistrationPage extends StatefulWidget {
  final User user;
  const RegistrationPage({super.key, required this.user});

  @override
  State<RegistrationPage> createState() => _RegistrationPageState();
}

class _RegistrationPageState extends State<RegistrationPage> {
  final _formKey = GlobalKey<FormState>();
  String _simType = 'SIM A';
  String _category = 'Baru';
  String _location = 'Polresta A';
  String _timeSlot = '10:00';
  File? _ktpImage;
  File? _oldSimImage;
  File? _photoImage;
  final ImagePicker _picker = ImagePicker();
  bool _isLoading = false;

  String? _ktpError;
  String? _oldSimError;
  String? _photoError;

  Future<void> _requestStoragePermission() async {
    try {
      if (Platform.isAndroid) {
        final status = await Permission.storage.request();
        
        if (status.isDenied) {
          if (mounted) {
            _showError('Storage permission ditolak');
          }
        } else if (status.isPermanentlyDenied) {
          openAppSettings();
        }
      }
    } catch (e) {
      print('Error requesting permission: $e');
    }
  }

  Future<void> _pickImage(String type) async {
    try {
      // Request permission dulu
      await _requestStoragePermission();

      setState(() => _isLoading = true);

      final XFile? pickedFile = await _picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 80,
        maxWidth: 1024,
        maxHeight: 1024,
      );

      if (pickedFile != null) {
        final file = File(pickedFile.path);
        
        // Check file exists
        if (!await file.exists()) {
          if (mounted) {
            _showError('File tidak ditemukan');
          }
          return;
        }

        // Validate file size
        final fileSize = await file.length();
        if (fileSize > 5 * 1024 * 1024) {
          if (mounted) {
            _showError('Ukuran file terlalu besar (max 5MB). Size: ${(fileSize / 1024 / 1024).toStringAsFixed(2)}MB');
          }
          return;
        }

        // Validate file type
        final extension = pickedFile.path.split('.').last.toLowerCase();
        if (!['jpg', 'jpeg', 'png'].contains(extension)) {
          if (mounted) {
            _showError('Format hanya boleh JPG/JPEG/PNG');
          }
          return;
        }

        setState(() {
          if (type == 'ktp') {
            _ktpImage = file;
            _ktpError = null;
          } else if (type == 'oldSim') {
            _oldSimImage = file;
            _oldSimError = null;
          } else if (type == 'photo') {
            _photoImage = file;
            _photoError = null;
          }
          _isLoading = false;
        });

        if (mounted) {
          _showSuccess('Foto berhasil diupload!');
        }
      } else {
        setState(() => _isLoading = false);
      }
    } catch (e) {
      print('Error picking image: $e');
      setState(() => _isLoading = false);
      if (mounted) {
        _showError('Error: ${e.toString()}');
      }
    }
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
        duration: const Duration(seconds: 4),
      ),
    );
  }

  void _showSuccess(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.green,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _showImagePreview(BuildContext context, File? image, String title) {
    if (image == null) return;
    
    showDialog(
      context: context,
      builder: (context) => Dialog(
        insetPadding: const EdgeInsets.all(20),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                title,
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 16),
              Image.file(
                image,
                height: 300,
                width: 300,
                fit: BoxFit.contain,
                errorBuilder: (context, error, stackTrace) {
                  return const Icon(Icons.error, size: 50, color: Colors.red);
                },
              ),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Tutup'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _removeImage(String type) {
    setState(() {
      if (type == 'ktp') {
        _ktpImage = null;
      } else if (type == 'oldSim') {
        _oldSimImage = null;
      } else if (type == 'photo') {
        _photoImage = null;
      }
    });
  }

  void _validateAndSubmit() {
    if (!_formKey.currentState!.validate()) return;

    try {
      final storage = AppStorage();
      final application = SIMApplication(
        id: storage.generateId(),
        userId: widget.user.email,
        userName: widget.user.name,
        simType: _simType,
        category: _category,
        ktpImage: _ktpImage?.path,
        oldSimImage: _oldSimImage?.path,
        photoImage: _photoImage?.path,
        location: _location,
        timeSlot: _timeSlot,
        status: 'pending',
        createdAt: DateTime.now(),
      );

      storage.addApplication(application);
      _showSuccess('Pendaftaran berhasil!');

      Future.delayed(const Duration(milliseconds: 1500), () {
        if (mounted) {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => PaymentPage(
                application: application,
                onBack: () => Navigator.pop(context),
              ),
            ),
          );
        }
      });
    } catch (e) {
      print('Error: $e');
      _showError('Gagal menyimpan data: ${e.toString()}');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Pendaftaran SIM'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Form Pendaftaran SIM',
                        style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    const Text('Isi data dengan lengkap dan benar',
                        style: TextStyle(color: Colors.grey)),
                    const SizedBox(height: 24),

                    // SIM Type
                    const Text('Jenis SIM *', style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: RadioListTile(
                            title: const Text('SIM A'),
                            value: 'SIM A',
                            groupValue: _simType,
                            onChanged: (v) => setState(() => _simType = v!),
                            dense: true,
                            contentPadding: EdgeInsets.zero,
                          ),
                        ),
                        Expanded(
                          child: RadioListTile(
                            title: const Text('SIM C'),
                            value: 'SIM C',
                            groupValue: _simType,
                            onChanged: (v) => setState(() => _simType = v!),
                            dense: true,
                            contentPadding: EdgeInsets.zero,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),

                    // Category
                    const Text('Kategori *', style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: RadioListTile(
                            title: const Text('Baru'),
                            value: 'Baru',
                            groupValue: _category,
                            onChanged: (v) => setState(() => _category = v!),
                            dense: true,
                            contentPadding: EdgeInsets.zero,
                          ),
                        ),
                        Expanded(
                          child: RadioListTile(
                            title: const Text('Perpanjang'),
                            value: 'Perpanjang',
                            groupValue: _category,
                            onChanged: (v) => setState(() => _category = v!),
                            dense: true,
                            contentPadding: EdgeInsets.zero,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 24),

                    const Text('Upload Dokumen (Opsional)',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 16),

                    _buildImageCard('Foto KTP', 'Unggah foto KTP yang jelas',
                        _ktpImage, _ktpError, () => _pickImage('ktp'),
                        () => _removeImage('ktp'),
                        () => _showImagePreview(context, _ktpImage, 'KTP'), 
                        isRequired: false),

                    const SizedBox(height: 16),

                    if (_category == 'Perpanjang')
                      Column(
                        children: [
                          _buildImageCard(
                              'Foto SIM Lama',
                              'Unggah foto SIM lama yang masih berlaku',
                              _oldSimImage,
                              _oldSimError,
                              () => _pickImage('oldSim'),
                              () => _removeImage('oldSim'),
                              () => _showImagePreview(context, _oldSimImage, 'SIM Lama'),
                              isRequired: false),
                          const SizedBox(height: 16),
                        ],
                      ),

                    _buildImageCard('Pas Foto', 'Unggah pas foto dengan background putih',
                        _photoImage, _photoError, () => _pickImage('photo'),
                        () => _removeImage('photo'),
                        () => _showImagePreview(context, _photoImage, 'Pas Foto'),
                        isRequired: false),

                    const SizedBox(height: 24),

                    const Text('Lokasi & Jadwal *',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 16),

                    _buildDropdown(
                      'Lokasi',
                      _location,
                      ['Polresta A', 'Polresta B', 'Polresta C'],
                      (v) => setState(() => _location = v!),
                    ),
                    const SizedBox(height: 16),

                    _buildDropdown(
                      'Jam',
                      _timeSlot,
                      ['10:00', '13:00', '15:00'],
                      (v) => setState(() => _timeSlot = v!),
                    ),

                    const SizedBox(height: 32),

                    SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: ElevatedButton(
                        onPressed: _validateAndSubmit,
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.blue),
                        child: const Text('Lanjut Pembayaran',
                            style: TextStyle(color: Colors.white, fontSize: 16)),
                      ),
                    ),
                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),
    );
  }

  Widget _buildImageCard(
    String title,
    String desc,
    File? image,
    String? error,
    VoidCallback onUpload,
    VoidCallback onRemove,
    VoidCallback onPreview,
    {bool isRequired = false}
  ) {
    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(
          color: error != null ? Colors.red : Colors.grey.shade300,
          width: error != null ? 2 : 1,
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                if (isRequired)
                  const Text(' *', style: TextStyle(color: Colors.red))
                else
                  const Text(' (Opsional)', style: TextStyle(color: Colors.orange, fontSize: 12)),
              ],
            ),
            const SizedBox(height: 4),
            Text(desc, style: const TextStyle(fontSize: 12, color: Colors.grey)),
            const SizedBox(height: 16),
            if (image != null)
              Column(
                children: [
                  GestureDetector(
                    onTap: onPreview,
                    child: Container(
                      height: 150,
                      width: double.infinity,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        image: DecorationImage(
                          image: FileImage(image),
                          fit: BoxFit.cover,
                        ),
                        border: Border.all(color: Colors.green, width: 2),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Text(
                          image.path.split('/').last,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 12),
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        onPressed: onRemove,
                      ),
                    ],
                  ),
                ],
              )
            else
              GestureDetector(
                onTap: onUpload,
                child: Container(
                  height: 150,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade100,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Colors.grey.shade300),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.cloud_upload, size: 48, color: Colors.grey.shade400),
                      const SizedBox(height: 12),
                      Text('Tap untuk upload',
                          style: TextStyle(color: Colors.grey.shade600, fontWeight: FontWeight.w500)),
                    ],
                  ),
                ),
              ),
            if (error != null)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Row(
                  children: [
                    const Icon(Icons.error, color: Colors.red, size: 16),
                    const SizedBox(width: 4),
                    Text(error, style: const TextStyle(color: Colors.red, fontSize: 12)),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildDropdown(String label, String value, List<String> items, Function(String?) onChanged) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(label, style: const TextStyle(fontWeight: FontWeight.bold)),
            const Text(' *', style: TextStyle(color: Colors.red)),
          ],
        ),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: Colors.grey.shade300),
          ),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: value,
              isExpanded: true,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              items: items.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
              onChanged: onChanged,
            ),
          ),
        ),
      ],
    );
  }
}