import 'package:flutter/material.dart';
import '../../models/user.dart';
import '../../models/sim_application.dart';
import '../../utils/app_storage.dart';
import '../../widgets/app_card.dart';
import '../../widgets/status_badge.dart';
import '../user/registration_page.dart';

class StatusPage extends StatelessWidget {
  final User user;
  final VoidCallback onBack;
  final VoidCallback onNavigateToRegistration;

  const StatusPage({
    super.key,
    required this.user,
    required this.onBack,
    required this.onNavigateToRegistration,
  });

  @override
  Widget build(BuildContext context) {
    final storage = AppStorage();
    final applications = storage.getUserApplications(user.email);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Status Pendaftaran'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: onBack,
        ),
      ),
      body: applications.isEmpty
          ? _buildEmptyState()
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: applications.length,
              itemBuilder: (context, index) {
                final app = applications[index];
                return _buildApplicationCard(app, context);
              },
            ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              color: Colors.blue.shade50,
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.checklist,
              size: 60,
              color: Colors.blue,
            ),
          ),
          const SizedBox(height: 24),
          const Text(
            'Belum ada pendaftaran',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            'Mulai ajukan permohonan SIM pertama Anda',
            style: TextStyle(
              color: Colors.grey,
              fontSize: 14,
            ),
          ),
          const SizedBox(height: 24),
          SizedBox(
            width: 200,
            height: 50,
            child: ElevatedButton(
              onPressed: onNavigateToRegistration,
              child: const Text('Ajukan Pendaftaran'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildApplicationCard(SIMApplication app, BuildContext context) {
    return AppCard(
      margin: const EdgeInsets.only(bottom: 12),
      onTap: () => _showApplicationDetails(app, context),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '${app.simType} - ${app.category}',
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      app.userName,
                      style: const TextStyle(
                        fontSize: 14,
                        color: Colors.grey,
                      ),
                    ),
                  ],
                ),
              ),
              StatusBadge(status: app.status),
            ],
          ),
          const SizedBox(height: 16),
          _buildDetailItem('Lokasi', app.location),
          _buildDetailItem('Jam', app.timeSlot),
          _buildDetailItem('Tanggal', 
            app.createdAt.toLocal().toString().split(' ')[0]),
          if (app.rejectionReason != null) ...[
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.red.shade50,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.red.shade100),
              ),
              child: Row(
                children: [
                  const Icon(Icons.info, size: 16, color: Colors.red),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      app.rejectionReason!,
                      style: const TextStyle(
                        fontSize: 13,
                        color: Colors.red,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildDetailItem(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          SizedBox(
            width: 80,
            child: Text(
              label,
              style: const TextStyle(
                fontSize: 13,
                color: Colors.grey,
              ),
            ),
          ),
          Text(
            value,
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  void _showApplicationDetails(SIMApplication app, BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      isScrollControlled: true,
      builder: (context) => SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 60,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade300,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 24),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Detail Permohonan',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  StatusBadge(status: app.status),
                ],
              ),
              const SizedBox(height: 24),
              _buildDetailSection(app),
              const SizedBox(height: 32),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Tutup'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDetailSection(SIMApplication app) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildDetailRow('Jenis SIM', app.simType),
        _buildDetailRow('Kategori', app.category),
        _buildDetailRow('Lokasi', app.location),
        _buildDetailRow('Jam', app.timeSlot),
        _buildDetailRow(
          'Tanggal Pendaftaran',
          app.createdAt.toLocal().toString().split(' ')[0],
        ),
        if (app.updatedAt != null)
          _buildDetailRow(
            'Terakhir Diupdate',
            app.updatedAt!.toLocal().toString().split(' ')[0],
          ),
        _buildDetailRow('Status Pembayaran', app.paymentStatus ?? '-'),
        const SizedBox(height: 16),
        const Text(
          'Dokumen:',
          style: TextStyle(
            fontWeight: FontWeight.w600,
            fontSize: 16,
          ),
        ),
        const SizedBox(height: 12),
        _buildDocumentStatus('KTP', app.ktpImage != null),
        if (app.category == 'Perpanjang')
          _buildDocumentStatus('SIM Lama', app.oldSimImage != null),
        _buildDocumentStatus('Pas Foto', app.photoImage != null),
      ],
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: const TextStyle(color: Colors.grey),
          ),
          Text(
            value,
            style: const TextStyle(fontWeight: FontWeight.w500),
          ),
        ],
      ),
    );
  }

  Widget _buildDocumentStatus(String document, bool isUploaded) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Icon(
            isUploaded ? Icons.check_circle : Icons.circle,
            size: 16,
            color: isUploaded ? Colors.green : Colors.grey,
          ),
          const SizedBox(width: 8),
          Text(document),
          const Spacer(),
          Text(
            isUploaded ? 'Terupload' : 'Belum',
            style: TextStyle(
              color: isUploaded ? Colors.green : Colors.grey,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
}