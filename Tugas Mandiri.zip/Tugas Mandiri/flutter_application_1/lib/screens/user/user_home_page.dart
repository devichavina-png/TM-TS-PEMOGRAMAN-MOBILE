import 'package:flutter/material.dart';
import '../../models/user.dart';
import 'home_dashboard.dart';
import 'status_page.dart';
import 'barcode_page.dart';
import 'history_page.dart';
import 'registration_page.dart';

class UserHomePage extends StatefulWidget {
  final User user;
  const UserHomePage({super.key, required this.user});

  @override
  State<UserHomePage> createState() => _UserHomePageState();
}

class _UserHomePageState extends State<UserHomePage> {
  int _selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _getPage(_selectedIndex),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: (index) => setState(() => _selectedIndex = index),
        type: BottomNavigationBarType.fixed,
        selectedItemColor: Colors.blue,
        unselectedItemColor: Colors.grey,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Beranda',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.info),
            label: 'Status',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.qr_code),
            label: 'Barcode',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.history),
            label: 'Riwayat',
          ),
        ],
      ),
    );
  }

  Widget _getPage(int index) {
    switch (index) {
      case 0:
        return HomeDashboard(
          user: widget.user,
          onNavigateToRegistration: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => RegistrationPage(user: widget.user),
              ),
            );
          },
          onNavigateToStatus: () => setState(() => _selectedIndex = 1),
        );
      case 1:
        return StatusPage(
          user: widget.user,
          onBack: () {
            setState(() => _selectedIndex = 0);
          },
          onNavigateToRegistration: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => RegistrationPage(user: widget.user),
              ),
            );
          },
        );
      case 2:
        return BarcodePage(
          user: widget.user,
          onBack: () {
            setState(() => _selectedIndex = 0);
          },
        );
      case 3:
        return HistoryPage(
          user: widget.user,
          onBack: () {
            setState(() => _selectedIndex = 0);
          },
          onNavigateToRegistration: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => RegistrationPage(user: widget.user),
              ),
            );
          },
        );
      default:
        return HomeDashboard(
          user: widget.user,
          onNavigateToRegistration: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => RegistrationPage(user: widget.user),
              ),
            );
          },
          onNavigateToStatus: () => setState(() => _selectedIndex = 1),
        );
    }
  }
}