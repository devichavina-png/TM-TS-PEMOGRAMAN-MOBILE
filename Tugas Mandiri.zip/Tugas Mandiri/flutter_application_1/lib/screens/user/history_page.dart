import 'package:flutter/material.dart';
import '../../models/user.dart';
import '../../utils/app_storage.dart';
import '../../widgets/app_card.dart';
import '../../widgets/status_badge.dart';

class HistoryPage extends StatelessWidget {
  final User user;
  final VoidCallback onBack;
  final VoidCallback onNavigateToRegistration;

  const HistoryPage({
    super.key,
    required this.user,
    required this.onBack,
    required this.onNavigateToRegistration,
  });

  @override
  Widget build(BuildContext context) {
    final storage = AppStorage();
    final applications = storage.getUserApplications(user.email);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Riwayat Pendaftaran'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: onBack,
        ),
      ),
      body: applications.isEmpty
          ? _buildEmptyState()
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: applications.length,
              itemBuilder: (context, index) {
                final app = applications[index];
                return _buildHistoryCard(app);
              },
            ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              color: Colors.blue.shade50,
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.history,
              size: 60,
              color: Colors.blue,
            ),
          ),
          const SizedBox(height: 24),
          const Text(
            'Belum ada riwayat pendaftaran',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            'Mulai ajukan permohonan SIM pertama Anda',
            style: TextStyle(
              color: Colors.grey,
              fontSize: 14,
            ),
          ),
          const SizedBox(height: 24),
          SizedBox(
            width: 200,
            height: 50,
            child: ElevatedButton(
              onPressed: onNavigateToRegistration,
              child: const Text('Ajukan Pendaftaran'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHistoryCard(application) {
    return AppCard(
      margin: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                '${application.simType} - ${application.category}',
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
              StatusBadge(status: application.status),
            ],
          ),
          const SizedBox(height: 12),
          _buildHistoryDetail(
            Icons.calendar_today,
            application.createdAt.toLocal().toString().split(' ')[0],
          ),
          if (application.location.isNotEmpty)
            _buildHistoryDetail(
              Icons.location_on,
              application.location,
            ),
          if (application.timeSlot.isNotEmpty)
            _buildHistoryDetail(
              Icons.access_time,
              application.timeSlot,
            ),
          if (application.rejectionReason != null) ...[
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.red.shade50,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                children: [
                  const Icon(Icons.info, size: 16, color: Colors.red),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      application.rejectionReason!,
                      style: const TextStyle(
                        fontSize: 12,
                        color: Colors.red,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildHistoryDetail(IconData icon, String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Icon(icon, size: 16, color: Colors.grey),
          const SizedBox(width: 8),
          Text(
            text,
            style: const TextStyle(
              fontSize: 14,
              color: Colors.grey,
            ),
          ),
        ],
      ),
    );
  }
}