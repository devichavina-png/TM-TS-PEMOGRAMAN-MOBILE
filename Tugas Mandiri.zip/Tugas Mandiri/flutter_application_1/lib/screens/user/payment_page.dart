import 'package:flutter/material.dart';
import '../../models/sim_application.dart';
import '../../utils/app_storage.dart';
import '../../utils/constants.dart';

class PaymentPage extends StatefulWidget {
  final SIMApplication application;
  final VoidCallback onBack;

  const PaymentPage({
    super.key,
    required this.application,
    required this.onBack,
  });

  @override
  State<PaymentPage> createState() => _PaymentPageState();
}

class _PaymentPageState extends State<PaymentPage> {
  String _selectedPayment = 'transfer_bank';
  bool _isProcessing = false;

  final Map<String, Map<String, String>> paymentMethods = {
    'transfer_bank': {
      'name': 'Transfer Bank',
      'icon': '🏦',
      'details': 'BCA, Mandiri, BNI, CIMB'
    },
    'kartu_kredit': {
      'name': 'Kartu Kredit',
      'icon': '💳',
      'details': 'Visa, Mastercard, Amex'
    },
    'e_wallet': {
      'name': 'E-Wallet',
      'icon': '📱',
      'details': 'GCash, Maya, Grab Pay'
    },
    'bank_transfer': {
      'name': 'Bank Transfer',
      'icon': '🏧',
      'details': 'ATM, Mobile Banking'
    },
  };

  void _processPayment() async {
    setState(() => _isProcessing = true);

    try {
      await Future.delayed(const Duration(seconds: 2));

      final storage = AppStorage();
      final updatedApp = SIMApplication(
        id: widget.application.id,
        userId: widget.application.userId,
        userName: widget.application.userName,
        simType: widget.application.simType,
        category: widget.application.category,
        ktpImage: widget.application.ktpImage,
        oldSimImage: widget.application.oldSimImage,
        photoImage: widget.application.photoImage,
        location: widget.application.location,
        timeSlot: widget.application.timeSlot,
        status: 'approved',
        createdAt: widget.application.createdAt,
        updatedAt: DateTime.now(),
      );

      storage.updateApplication(updatedApp);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Pembayaran berhasil! Silakan cek status pendaftaran Anda.'),
            backgroundColor: Colors.green,
            duration: Duration(seconds: 3),
          ),
        );

        Future.delayed(const Duration(seconds: 2), () {
          if (mounted) {
            Navigator.pushNamedAndRemoveUntil(
              context,
              '/home',
              (route) => false,
            );
          }
        });
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: ${e.toString()}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _isProcessing = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final price = AppConstants.prices[widget.application.simType] ?? 150000;
    final tax = (price * 0.1).toInt();
    final total = price + tax;

    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Pembayaran'),
          centerTitle: true,
          elevation: 0,
          backgroundColor: Colors.blue,
          leading: const SizedBox.shrink(),
        ),
        body: _isProcessing
            ? const Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CircularProgressIndicator(),
                    SizedBox(height: 16),
                    Text('Memproses pembayaran...'),
                  ],
                ),
              )
            : SingleChildScrollView(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.blue.shade50,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.blue.shade200),
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 50,
                            height: 50,
                            decoration: BoxDecoration(
                              color: Colors.blue,
                              borderRadius: BorderRadius.circular(25),
                            ),
                            child: const Icon(Icons.check_circle,
                                color: Colors.white, size: 28),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text('Pendaftaran Berhasil Disimpan',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16,
                                    )),
                                const SizedBox(height: 4),
                                Text('ID: ${widget.application.id}',
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: Colors.grey.shade600,
                                    )),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 24),

                    const Text('Detail Pendaftaran',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        )),
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.grey.shade50,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: Colors.grey.shade200),
                      ),
                      child: Column(
                        children: [
                          _buildDetailItem('Nama', widget.application.userName),
                          const Divider(height: 16),
                          _buildDetailItem('Jenis SIM', widget.application.simType),
                          const Divider(height: 16),
                          _buildDetailItem('Kategori', widget.application.category),
                          const Divider(height: 16),
                          _buildDetailItem('Lokasi', widget.application.location),
                          const Divider(height: 16),
                          _buildDetailItem('Jam Pelayanan', widget.application.timeSlot),
                        ],
                      ),
                    ),

                    const SizedBox(height: 24),

                    const Text('Rincian Biaya',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        )),
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.grey.shade50,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: Colors.grey.shade200),
                      ),
                      child: Column(
                        children: [
                          _buildPriceItem(
                            'Biaya Pendaftaran ${widget.application.simType}',
                            price,
                          ),
                          const Divider(height: 16),
                          _buildPriceItem('PPN 10%', tax),
                          const Divider(height: 16),
                          Row(
                            mainAxisAlignment:
                                MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('Total Pembayaran',
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16,
                                  )),
                              Text('Rp ${total.toStringAsFixed(0)}',
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16,
                                    color: Colors.blue.shade700,
                                  )),
                            ],
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 24),

                    const Text('Pilih Metode Pembayaran',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        )),
                    const SizedBox(height: 12),
                    Column(
                      children: paymentMethods.entries.map((entry) {
                        final key = entry.key;
                        final method = entry.value;
                        final isSelected = _selectedPayment == key;

                        return GestureDetector(
                          onTap: () =>
                              setState(() => _selectedPayment = key),
                          child: Container(
                            margin: const EdgeInsets.only(bottom: 12),
                            padding: const EdgeInsets.all(16),
                            decoration: BoxDecoration(
                              color: isSelected
                                  ? Colors.blue.shade50
                                  : Colors.white,
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color: isSelected
                                    ? Colors.blue
                                    : Colors.grey.shade300,
                                width: isSelected ? 2 : 1,
                              ),
                            ),
                            child: Row(
                              children: [
                                Text(method['icon']!,
                                    style:
                                        const TextStyle(fontSize: 28)),
                                const SizedBox(width: 16),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(method['name']!,
                                          style: const TextStyle(
                                            fontWeight:
                                                FontWeight.bold,
                                            fontSize: 14,
                                          )),
                                      const SizedBox(height: 4),
                                      Text(method['details']!,
                                          style: TextStyle(
                                            fontSize: 12,
                                            color:
                                                Colors.grey.shade600,
                                          )),
                                    ],
                                  ),
                                ),
                                if (isSelected)
                                  Container(
                                    width: 24,
                                    height: 24,
                                    decoration: BoxDecoration(
                                      color: Colors.blue,
                                      borderRadius:
                                          BorderRadius.circular(12),
                                    ),
                                    child: const Icon(
                                        Icons.check,
                                        color: Colors.white,
                                        size: 16),
                                  ),
                              ],
                            ),
                          ),
                        );
                      }).toList(),
                    ),

                    const SizedBox(height: 24),

                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.orange.shade50,
                        borderRadius: BorderRadius.circular(10),
                        border:
                            Border.all(color: Colors.orange.shade200),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.info,
                              color: Colors.orange.shade700, size: 20),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              'Pembayaran akan diproses segera setelah Anda mengklik tombol "Bayar Sekarang".',
                              style: TextStyle(
                                fontSize: 12,
                                color: Colors.orange.shade800,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 24),

                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton(
                            onPressed: () => Navigator.pop(context),
                            style: OutlinedButton.styleFrom(
                              padding: const EdgeInsets.symmetric(
                                  vertical: 12),
                              side: const BorderSide(
                                  color: Colors.grey),
                            ),
                            child: const Text('Kembali',
                                style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 16)),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: ElevatedButton(
                            onPressed: _isProcessing
                                ? null
                                : _processPayment,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.blue,
                              padding: const EdgeInsets.symmetric(
                                  vertical: 12),
                              disabledBackgroundColor: Colors.grey,
                            ),
                            child: const Text(
                              'Bayar Sekarang',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                  ],
                ),
              ),
      ),
    );
  }

  Widget _buildDetailItem(String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label,
            style: TextStyle(fontSize: 12, color: Colors.grey.shade600)),
        Text(value,
            style: const TextStyle(
              fontWeight: FontWeight.w500,
              fontSize: 14,
            )),
      ],
    );
  }

  Widget _buildPriceItem(String label, int amount) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label,
            style: TextStyle(fontSize: 12, color: Colors.grey.shade600)),
        Text('Rp ${amount.toStringAsFixed(0)}',
            style: const TextStyle(
              fontWeight: FontWeight.w500,
              fontSize: 14,
            )),
      ],
    );
  }
}