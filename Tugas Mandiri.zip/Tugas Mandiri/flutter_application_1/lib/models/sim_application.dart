class SIMApplication {
  final String id;
  final String userId;
  final String userName;
  final String simType;
  final String category;
  final String? ktpImage;
  final String? oldSimImage;
  final String? photoImage;
  final String location;
  final String timeSlot;
  final String status;
  final String? paymentStatus;
  final String? rejectionReason;
  final String? adminNotes; // Untuk catatan admin
  final String? validationStatus; // 'pending', 'valid', 'invalid'
  final DateTime createdAt;
  final DateTime? updatedAt;

  SIMApplication({
    required this.id,
    required this.userId,
    required this.userName,
    required this.simType,
    required this.category,
    this.ktpImage,
    this.oldSimImage,
    this.photoImage,
    required this.location,
    required this.timeSlot,
    this.status = 'pending',
    this.paymentStatus,
    this.rejectionReason,
    this.adminNotes,
    this.validationStatus = 'pending',
    required this.createdAt,
    this.updatedAt,
  });

  SIMApplication copyWith({
    String? status,
    String? rejectionReason,
    String? adminNotes,
    String? validationStatus,
    DateTime? updatedAt,
  }) {
    return SIMApplication(
      id: id,
      userId: userId,
      userName: userName,
      simType: simType,
      category: category,
      ktpImage: ktpImage,
      oldSimImage: oldSimImage,
      photoImage: photoImage,
      location: location,
      timeSlot: timeSlot,
      status: status ?? this.status,
      rejectionReason: rejectionReason ?? this.rejectionReason,
      adminNotes: adminNotes ?? this.adminNotes,
      validationStatus: validationStatus ?? this.validationStatus,
      createdAt: createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}